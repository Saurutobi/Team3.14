@layout('layouts.simple')

@section('title')
<title>LOGIN</title>
@endsection

@section('content')
<p class="text-center h2">Login<p>
{{ Form::open('login') }}

    <!-- check for login errors flash var -->
    @if (Session::has('login_errors'))
        <span class="error">Username or password incorrect.</span>
    @endif

    <!-- username field -->
    <p class="text-center">{{ Form::label('username', 'Username') }}</p>
    <p class="text-center">{{ Form::text('username') }}</p>

    <!-- password field -->
    <p class="text-center">{{ Form::label('password', 'Password') }}</p>
    <p class="text-center">{{ Form::password('password') }}</p>

    <!-- submit button -->
    <p class="text-center">{{ Form::submit('Login') }}</p>

{{ Form::close() }}
@endsection
