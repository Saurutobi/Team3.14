$( document ).ready(function() {
/*     $.getJSON('nonempty_rooms', function(data){ 
		$.each(data[0], function(key,value) {
			// alert(key + ": " + value);
		});
	}); */
	
	
	$(".collapsableHeader").click(function () {
		
		
		
		$header = $(this);
		$thisid = this.id;
		$thisname = $(this).attr("name");
		
		//getting the next element
		$content = $header.next();
		//open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
		$content.slideToggle(500, function () {
				
			// TEMPERATURES
			$.getJSON('by_room/' + $thisid, function(data){  //gets chart data by room id							
				var seriesOptions = [],
					yAxisOptions = [],
					devices = [],
					seriesCounter = 0,
					colors = Highcharts.getOptions().colors;
					
				for(var i = 0; i < data.length; ++i)
				{
					seriesOptions[i] = 
					{
						name: data[i][0],
						data: data[i][1]
					};
				}
				createTempChart($thisname, seriesOptions);
			})
			.done(function() {
				console.log( "success" );
			});;
			
			// HUMIDITIES
			$.getJSON('hum_by_room/' + $thisid, function(data){  //gets chart data by room id							
				var seriesOptions = [],
					yAxisOptions = [],
					devices = [],
					seriesCounter = 0,
					colors = Highcharts.getOptions().colors;
					
				for(var i = 0; i < data.length; ++i)
				{
					seriesOptions[i] = 
					{
						name: data[i][0],
						data: data[i][1]
					};
				}
				createHumChart($thisname, seriesOptions);
			})
			.done(function() {
				console.log( "success" );
			});;
		});
	});
	
	$(".collapsableHeader").each(function () {

		$header = $(this);
		$content = $header.next();
		$content.slideToggle(0, function () {

		});
	});
});




// create the chart when all data is loaded
function createTempChart(room_name, seriesOptions) {

	chart = new Highcharts.StockChart({
		chart: {
			//renderTo: 'temperatures_over_time'
			renderTo: 'tempChart' + $thisname
		},

	    title : {
	    	text : room_name + ' Temperature'
	    },
		
		scrollbar : {
            enabled : false
        },

		rangeSelector: {
			buttons: [{
				type: 'day',
				count: 1,
				text: '1d'
			}, {
				type: 'week',
				count: 1,
				text: '1w'
			}, {
				type: 'month',
				count: 1,
				text: '1m'
			}, {
				type: 'month',
				count: 6,
				text: '6m'
			}, {

				type: 'all',
				text: 'All'
			}],

			// whether to have it enabled
			enabled: false,
			
	        // which button to start with initially
	        selected:0
	    },

	 credits: { enabled: false },

    legend: {
    	enabled: false,
    	align: 'right',
    	backgroundColor: '#FCFFC5',
    	borderColor: 'black',
    	borderWidth: 2,
    	layout: 'vertical',
    	verticalAlign: 'top',
    	y: 100,
    	shadow: true
    },
	        navigator: {
            enabled: false
        },

	    yAxis : {
	    	title : {
	    		text : 'temperatures'
	    	},

	    	// min:50, 
	    	// max: 100,

	    	style: {
            	color: '#313030',
            	font: '12px Helvetica',
            	fontWeight: 'bold'
        	},

            plotBands: [{
                from: 50,
                to: 67,
                color: 'rgba(102, 255, 51, 0.3)',
                label: {
                    text: 'optimal',
                }
            }, {
                from: 67,
                to: 80,
                color: 'rgba(234, 234, 24, 0.3)',
                label: {
                    text: 'warning'
                }
            }, {
                from: 80,
                to: 90,
                color: 'rgba(255, 0, 0, .5)',
                label: {
                    text: 'Alert'
                }
            }, { 
                from: 90,
                to: 1000,
                color: 'rgba(255, 0, 0, 1)',
                label: {
                    text: 'CRITICAL',
                }
            }]
        },
	    plotOptions: {
	    	line: { 
	    		allowPointSelect: true 
	    	}
	    },	    
	    
	    series: seriesOptions
	}); 
}

// create the chart when all data is loaded
function createHumChart(room_name, seriesOptions) {

	chart = new Highcharts.StockChart({
		chart: {
			//renderTo: 'temperatures_over_time'
			renderTo: 'humChart' + $thisname
		},

	    title : {
	    	text : room_name + ' Humidity'
	    },
		
		scrollbar : {
			enabled : false
		},

		rangeSelector: {
			buttons: [{
				type: 'day',
				count: 1,
				text: '1d'
			}, {
				type: 'week',
				count: 1,
				text: '1w'
			}, {
				type: 'month',
				count: 1,
				text: '1m'
			}, {
				type: 'month',
				count: 6,
				text: '6m'
			}, {

				type: 'all',
				text: 'All'
			}],

			// whether to have it enabled
			enabled: false,
			
	        // which button to start with initially
	        selected:0
	    },

	 credits: { enabled: false },

    legend: {
    	enabled: false,
    	align: 'right',
    	backgroundColor: '#FCFFC5',
    	borderColor: 'black',
    	borderWidth: 2,
    	layout: 'vertical',
    	verticalAlign: 'top',
    	y: 100,
    	shadow: true
    },
	        navigator: {
            enabled: false
        },

	    yAxis : {
	    	title : {
	    		text : 'humidities'
	    	},

	    	// min:50, 
	    	// max: 100,

	    	style: {
            	color: '#313030',
            	font: '12px Helvetica',
            	fontWeight: 'bold'
        	},

            plotBands: [{
                from: 0,
                to: 60,
                color: 'rgba(102, 255, 51, 0.3)',
                label: {
                    text: 'optimal',
                }
            }, {
                from: 60,
                to: 65,
                color: 'rgba(234, 234, 24, 0.3)',
                label: {
                    text: 'warning'
                }
            }, {
                from: 65,
                to: 70,
                color: 'rgba(255, 0, 0, .5)',
                label: {
                    text: 'Alert'
                }
            }, { 
                from: 70,
                to: 1000,
                color: 'rgba(255, 0, 0, 1)',
                label: {
                    text: 'CRITICAL',
                }
            }]
        },
	    plotOptions: {
	    	line: { 
	    		allowPointSelect: true 
	    	}
	    },	    
	    
	    series: seriesOptions
	}); 
}