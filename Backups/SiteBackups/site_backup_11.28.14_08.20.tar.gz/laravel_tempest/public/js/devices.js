$( document ).ready(function() {
	$('#btnDevices').addClass('active');
});