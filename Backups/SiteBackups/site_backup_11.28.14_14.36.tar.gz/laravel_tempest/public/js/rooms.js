$( document ).ready(function() {
	$('#btnRooms').addClass('active');
});