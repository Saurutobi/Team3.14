$( document ).ready(function() {
	$('#btnLogin').addClass('active');
});