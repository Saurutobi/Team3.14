@layout('layouts.default')

@section('title')
<title>System Details</title>
@endsection


@section('include')
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script type="text/javascript" src = "js/edit.js"></script>
	<script src="{{ URL::to_asset("js/admin.js") }}"></script>	
@endsection

@section('glance')

@endsection


@section('content')


{{Form::token()}}

					
	<div class="row">
		<div id = "roomsTab" class="col-md-12 collapsableContainer">
			<div class="panel-heading collapsableHeader">
				<span>Rooms</span>
			</div>
			<div class="collapsableContent">
				<div class="col-md-4">
					<div class="panel panel-success">
						<table id="roomsTable" class="table table-striped">
							<thead>
								<tr>
									<td>ID</td>
									<td>Name</td>
								</tr>
							</thead>
							<tbody>
								@foreach($rooms as $room)
								<tr class="{{e($room->name)}}" id={{$room->id}}>	
									<td>{{$room->id}}</td>
									
									<td class='editable'>{{e($room->name)}}</td>
									@if(Auth::user()->is_admin)
									<td >
										<a class="edit_link"> {{HTML::link_to_route('edit_room', 'edit', array($room->id), array('class'=>'btn btn-info btn-sm active btn-block', 'role'=>'button'));}}
									</td>
									<td >
										<a class="delete_link btn btn-danger btn-sm active btn-block" role="button" href={{ URL::to_route('delete_room', array($room->id)); }} onclick="return confirm('Do You Really Want to remove this room? (all devices and associated data will be lost permanently)');">remove</a>
									</td>
									@endif
								</tr>
								@endforeach
							</tbody>
						</table>

						@if(Auth::user()->is_admin)
						<p> {{HTML::link_to_route('add_room', 'Add Room', null, array('class'=>'btn btn-success btn-sm active btn-block', 'role'=>'button'));}} </p>
						@endif
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div id = "devicesTab" class="col-md-12 collapsableContainer">
			<div class="panel-heading collapsableHeader">
				<span>Devices</span>
			</div>
			<div class="collapsableContent">
				<div class="col-md-12">
					<div class="panel panel-success">
						<table id="devicesTable" class="table table-striped table-responsive">
							<thead>
								<tr>
									<td>ID</td>
									<td>Name</td>
									<td>Location</td>
									<td>IP Address</td>
									<td>Type</td>
									<td>Ports</td>
									<td>Warning</td>
									<td>Alert</td>
									<td>Critical</td>
									<td>Status</td>
								</tr>
							</thead>
					
							<tbody>
								@foreach($devices as $device)
								<tr id={{$device->id}}>	
									<td>{{$device->id}}</td>
									<td class='editable'>{{e($device->name)}}</td>
									<td class='editable'>{{e($device->room_id)}}</td>
									<td class='editable'>{{e($device->ip_address)}}</td>
									<td class='editable'>{{e($device->type)}}</td>
									<td class='editable'>{{e($device->ports)}}</td>
									<td class='editable'>{{e($device->warning_threshold)}}</td>
									<td class='editable'>{{e($device->alert_threshold)}}</td>
									<td class='editable'>{{e($device->critical_threshold)}}</td>
									<td >{{$device->status}}</td>
									@if(Auth::user()->is_admin)
									<td >
										<a class="edit_link"> {{HTML::link_to_route('edit_device', 'edit', array($device->id), array('class'=>'btn btn-info btn-sm active btn-block', 'role'=>'button'));}}</a>
									</td>
									<td >
										<a class="delete_link btn btn-danger btn-sm active btn-block" role="button" href={{ URL::to_route('delete_device', array($device->id)); }} onclick="return confirm('Do You Really Want to remove this room? (all devices and associated data will be lost permanently)');">remove</a>
									</td>
									@endif
								@endforeach
							</tbody>
						</table>

						@if(Auth::user()->is_admin)
						<p> {{HTML::link_to_route('add_device', 'Add Device', null, array('class'=>'btn btn-success btn-sm active btn-block', 'role'=>'button'))}} </p>
						@endif
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div id="usersTab" class="col-md-12 collapsableContainer">
			<div class="panel-heading collapsableHeader">
				<span>Users</span>
			</div>
			<div class="collapsableContent">
				<div class="col-md-12">
					<div class="panel panel-success">
						<table id="usersTable" class="table table-striped table-responsive">
							<thead>
								<tr>
									<td>ID</td>
									<td>Name</td>
									<td>E-mail</td>
									<td>Verified</td>
									<td>Phone</td>
									<td>Verified</td>
									<td>Carrier</td>
									<td>Admin</td>
								</tr>
							</thead>

							<tbody>
								@foreach($users as $user)
								<tr id={{e($user->id)}}>
									<td>{{e($user->id)}}</td>	
									<td class='editable'>{{e($user->username)}}</td>
									<td class='editable'>{{e($user->email)}}</td>
									
									@if($user->email_verified == 1)
										<td>yes</td>
									@else
										<td>no</td>
									@endif

									<td class='editable'>{{e($user->phone)}}</td>

									@if($user->phone_verified == 1)
										<td>yes</td>
									@else
										<td>no</td>
									@endif

									<td class='editable'>{{e($user->carrier)}}</td>

									@if($user->is_admin == 1)
										<td>yes</td>
									@else
										<td>no</td>
									@endif

									@if(Auth::user()->is_admin)
									<td >
										<a class="verify_link"> {{HTML::link_to_route('verify_user', 'verify', array($user->id), array('class'=>'btn btn-warning btn-sm active btn-block', 'role'=>'button'));}}</a>
									</td>

									<td >
										<a class="edit_link"> {{HTML::link_to_route('edit_user', 'edit', array($user->id), array('class'=>'btn btn-info btn-sm active btn-block', 'role'=>'button'));}}</a>
									</td>
									<td >
										<a class="delete_link btn btn-danger btn-sm active btn-block" href={{ URL::to_route('delete_user', array($user->id)); }} onclick="return confirm('are you sure you want to delete this user? (all associated assignments will be deleted.)');" role="button">remove</a>
								</td>
								@endif
								</tr>
								@endforeach
							</tbody>
						</table>
					
						@if(Auth::user()->is_admin)
						<p> {{HTML::link_to_route('add_user', 'Add user', null, array('class'=>'btn btn-success btn-sm active btn-block', 'role'=>'button'))}} </p>
						@endif
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">	
		<div id="assignmentsTab" class="col-md-12 collapsableContainer">
		<div class="panel-heading collapsableHeader">
				<span>Room Assignments</span>
			</div>
			<div class="collapsableContent">
				<div class="col-md-4">
					<div class="panel panel-success">
						<table id="roomAssignments" class="table table-striped">

						@foreach ($rooms as $room)
							<?php 
								$roomUserCount = 0;
								foreach($assignments as $assignment)
								{
									if($assignment->room_id == $room->id)
									{
										foreach($users as $user)
										{
											if($user->id == $assignment->user_id)
											{
												++$roomUserCount;
											}
										}
									}
								
								}				
							?>
							@if($roomUserCount > 0)
								<thead>
									<td>{{e($room->name)}}</td>
								<thead>

								@foreach($assignments as $assignment)
									<tbody>
										@if($assignment->room_id == $room->id)
											@foreach($users as $user)
												@if($user->id == $assignment->user_id)
													<tr>
														<td><p class="indentP">{{e($user->username)}}</p></td>
														@if(Auth::user()->is_admin)
															<td>
																<a class="delete_link btn btn-danger btn-sm active btn-block" href={{ URL::to_route('delete_assignment', array($assignment->id)); }} onclick="return confirm('are you sure you want to delete this assignment?');" role="button">remove</a>
															</td>
														@endif
													</tr>
												@endif
											@endforeach
										@endif
									</tbody>
								@endforeach
							@endif
						@endforeach
						</table>

						@if(Auth::user()->is_admin)
						<p> {{HTML::link_to_route('add_assignment', 'Add Assignment', null, array('class'=>'btn btn-success btn-sm active btn-block', 'role'=>'button'))}}</p>
						@endif
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div id = "typesTab" class="col-md-12 collapsableContainer">
			<div class="panel-heading collapsableHeader">
				<span>Device Types</span>
			</div>
			<div class="collapsableContent">
				<div class="col-md-4">
					<div class="panel panel-success">
						<table id="typesTable" class="table table-striped">
							<thead>
								<tr>
									<td>ID</td>
									<td>Name</td>
								</tr>
							</thead>
							<tbody>
								@foreach($deviceTypes as $type)
								<tr class={{e($type->name)}} id={{e($type->id)}}>	
									<td>{{$type->id}}</td>
									<td class='editable'>{{$type->name}}</td>
									<td>
									@if(Auth::user()->is_admin)
										<a href={{ URL::to_route('delete_devicetype', array($type->id)); }} onclick="return confirm('are you sure you want to delete this device type? (Please verify no other devices are using it.)');" class="btn btn-danger btn-sm active btn-block" role="button">remove</a>
									</td>
									@endif
								</tr>
								@endforeach
							</tbody>
						</table>

						@if(Auth::user()->is_admin)
						<p> {{HTML::link_to_route('add_devicetype', 'Add Device Type', null, array('class'=>'btn btn-success btn-sm active btn-block', 'role'=>'button')) }} </p>
						@endif
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection