$( document ).ready(function() {
	$('#btnHome').addClass('active');
});