/**
	@file	logging.h
	@breif	just contains a definition for LOG which toggles logging
*/
#define LOG 1
