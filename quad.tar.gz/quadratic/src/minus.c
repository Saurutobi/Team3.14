/**
	@file	minus.c
	@brief	Determines the - root of the +/- root situation


*/
#include "logging.h"
#include <stdio.h>
#include <math.h>

float SquareRoot(float, float, float);


float QuadraticMinus(float a, float b, float c)
{
	float x1;
	float sqroot;

	sqroot = SquareRoot(a, b, c);

	if((pow(b, 2) - 4. * a * c) > 0)
	{
		x1 = (-b - sqroot) / (2 * a);

		#if LOG > 0
			printf("Logging for Quadratic Minus\n");
			printf("\na = %f\nb = %f\nc = %f\n",a,b,c);
			printf("x1 = %f\n", x1);
		#endif
	}	
	else
	{
		printf("The result for quadratic minus is a non-real number\n");
	}
	return x1;
}
