Use the make file to compile


Old version of instructions
cd to directory
Compile: gcc -o quad quadratic.c -lm	lm is needed because sqrt() and pow() are not defined by <math.h>
Run: ./quad
