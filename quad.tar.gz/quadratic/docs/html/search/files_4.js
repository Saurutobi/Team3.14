var searchData=
[
  ['quadratic_2ec',['quadratic.c',['../quadratic_8c.html',1,'']]],
  ['quadratic_2eh',['quadratic.h',['../quadratic_8h.html',1,'']]]
];
