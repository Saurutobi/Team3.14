var searchData=
[
  ['getavalue',['GetAValue',['../quadratic_8h.html#a517cf575b5947b71b02dea542c5a20d9',1,'GetAValue(char letter):&#160;acceptInput.c'],['../t3_8c.html#afcc56b8d3cc44f35f40ac4d35e54317e',1,'GetAValue(char a):&#160;acceptInput.c']]]
];
