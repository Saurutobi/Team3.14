var searchData=
[
  ['logging_2eh',['logging.h',['../logging_8h.html',1,'']]]
];
