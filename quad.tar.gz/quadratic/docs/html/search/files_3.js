var searchData=
[
  ['plus_2ec',['plus.c',['../plus_8c.html',1,'']]]
];
