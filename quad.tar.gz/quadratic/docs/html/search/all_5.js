var searchData=
[
  ['quadratic_2ec',['quadratic.c',['../quadratic_8c.html',1,'']]],
  ['quadratic_2eh',['quadratic.h',['../quadratic_8h.html',1,'']]],
  ['quadraticminus',['QuadraticMinus',['../minus_8c.html#a0f03f314cfe6bb49fcde79afeaacd53a',1,'QuadraticMinus(float a, float b, float c):&#160;minus.c'],['../quadratic_8h.html#a741645716bff255fbacf5b26f613b6f2',1,'QuadraticMinus(float, float, float):&#160;minus.c'],['../t1_8c.html#a0f03f314cfe6bb49fcde79afeaacd53a',1,'QuadraticMinus(float a, float b, float c):&#160;minus.c']]],
  ['quadraticplus',['QuadraticPlus',['../plus_8c.html#a18aad6f9ec2ab6408fc48cb52f39b75b',1,'QuadraticPlus(float a, float b, float c):&#160;plus.c'],['../quadratic_8h.html#a36979b809266a7d1021afe19f3a9d0f7',1,'QuadraticPlus(float, float, float):&#160;plus.c'],['../t2_8c.html#a18aad6f9ec2ab6408fc48cb52f39b75b',1,'QuadraticPlus(float a, float b, float c):&#160;plus.c']]]
];
