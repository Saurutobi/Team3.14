var searchData=
[
  ['minus_2ec',['minus.c',['../minus_8c.html',1,'']]]
];
